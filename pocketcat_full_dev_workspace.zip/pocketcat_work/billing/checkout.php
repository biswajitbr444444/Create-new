<?php
require __DIR__.'/../bootstrap.php';
require_login();
ensure_billing_workflow_schema();
billing_process_expirations();
$user=current_user();
$uid=(int)$user['id'];
$plan=(string)getv('plan','');
$cycle=(string)getv('cycle','month');
$catalog=plan_catalog();
$meta=$catalog['plan_meta'][$plan]??null;
if(!in_array($plan,['basic','premium'],true)||!is_array($meta)||empty($meta['enabled'])||!in_array($cycle,['month','year'],true)){
    http_response_code(404);
    exit('The selected plan or billing cycle is unavailable.');
}
$amount=billing_plan_amount($plan,$cycle);
$addressesQuery=db()->prepare('SELECT * FROM user_billing_addresses WHERE user_id=? ORDER BY updated_at DESC,id DESC');
$addressesQuery->execute([$uid]);
$addresses=$addressesQuery->fetchAll();
$defaultAddress=(int)($addresses[0]['id']??0);
$methods=['UPI'=>'UPI / QR','Bank Transfer'=>'Bank Transfer','Card'=>'Credit / Debit Card'];
$methodDetails=[
    'UPI'=>setting('billing_upi_details','Payment details have not been configured yet. Please contact Billing Support.'),
    'Bank Transfer'=>setting('billing_bank_details','Bank transfer details have not been configured yet. Please contact Billing Support.'),
    'Card'=>setting('billing_card_instructions','Card payment instructions have not been configured yet. Please contact Billing Support.'),
];
$qrUrl=trim((string)setting('billing_upi_qr_url',''));
$allowedQr=$qrUrl!=='' && ((str_starts_with($qrUrl,'/')&&!str_starts_with($qrUrl,'//'))||(filter_var($qrUrl,FILTER_VALIDATE_URL)&&strtolower((string)parse_url($qrUrl,PHP_URL_SCHEME))==='https'));

if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    $postedPlan=(string)post('plan','');
    $postedCycle=(string)post('cycle','');
    if($postedPlan!==$plan||$postedCycle!==$cycle){
        flash('error','The selected plan changed. Please choose it again.');
        redirect('/billing/');
    }
    $paymentMethod=(string)post('payment_method','');
    if(!isset($methods[$paymentMethod])){
        flash('error','Choose a valid payment method.');
        redirect('/billing/checkout/?plan='.rawurlencode($plan).'&cycle='.rawurlencode($cycle));
    }
    $paymentReference=trim((string)post('payment_reference',''));
    if(strlen($paymentReference)>190)$paymentReference=substr($paymentReference,0,190);
    $proofFile=$_FILES['payment_proof']??null;
    $proofUploaded=$proofFile && (int)($proofFile['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE;
    if(!$proofUploaded&&$paymentReference===''){
        flash('error','Upload payment proof or enter a transaction/reference ID.');
        redirect('/billing/checkout/?plan='.rawurlencode($plan).'&cycle='.rawurlencode($cycle));
    }
    $address=[];
    $addressMode=(string)post('billing_choice','existing');
    if($addressMode==='existing'){
        $addressId=(int)post('billing_address_id',0);
        $q=db()->prepare('SELECT * FROM user_billing_addresses WHERE id=? AND user_id=?');
        $q->execute([$addressId,$uid]);
        $address=$q->fetch()?:[];
        if(!$address){
            flash('error','Choose one of your saved billing addresses or add new billing details.');
            redirect('/billing/checkout/?plan='.rawurlencode($plan).'&cycle='.rawurlencode($cycle));
        }
    }elseif($addressMode==='new'){
        $address=[
            'label'=>trim((string)post('billing_label','Billing address')),
            'billing_name'=>trim((string)post('billing_name','')),
            'email'=>trim((string)post('billing_email','')),
            'phone'=>trim((string)post('billing_phone','')),
            'company_name'=>trim((string)post('company_name','')),
            'address_line_1'=>trim((string)post('address_line_1','')),
            'address_line_2'=>trim((string)post('address_line_2','')),
            'city'=>trim((string)post('city','')),
            'state_province'=>trim((string)post('state_province','')),
            'postal_code'=>trim((string)post('postal_code','')),
            'country'=>strtoupper(trim((string)post('country',''))),
        ];
        if($address['billing_name']===''||!valid_email($address['email'])||$address['address_line_1']===''||$address['city']===''||$address['state_province']===''||$address['postal_code']===''||!preg_match('/^[A-Z]{2}$/',$address['country'])){
            flash('error','Complete the required billing name, email, address, city, state, postal code, and two-letter country code.');
            redirect('/billing/checkout/?plan='.rawurlencode($plan).'&cycle='.rawurlencode($cycle));
        }
        foreach(['billing_name'=>180,'email'=>190,'phone'=>40,'company_name'=>180,'address_line_1'=>255,'address_line_2'=>255,'city'=>120,'state_province'=>120,'postal_code'=>40,'label'=>80] as $key=>$limit){
            if(strlen((string)$address[$key])>$limit)throw new RuntimeException('Billing '.$key.' is too long.');
        }
    }else{
        flash('error','Choose existing or new billing details.');
        redirect('/billing/checkout/?plan='.rawurlencode($plan).'&cycle='.rawurlencode($cycle));
    }

    $savedProof=null;
    try{
        if($proofUploaded){
            if((int)($proofFile['error']??UPLOAD_ERR_OK)!==UPLOAD_ERR_OK)throw new RuntimeException('Payment proof upload failed. Choose the file again.');
            if((int)($proofFile['size']??0)>8*1024*1024)throw new RuntimeException('Payment proof must be 8 MB or smaller.');
            $temp=(string)($proofFile['tmp_name']??'');
            if($temp===''||!is_uploaded_file($temp))throw new RuntimeException('Payment proof is invalid.');
            $extension=strtolower(pathinfo((string)($proofFile['name']??''),PATHINFO_EXTENSION));
            $mime=(new finfo(FILEINFO_MIME_TYPE))->file($temp)?:'';
            $proofTypes=['png'=>['image/png'],'jpg'=>['image/jpeg'],'jpeg'=>['image/jpeg'],'webp'=>['image/webp'],'pdf'=>['application/pdf']];
            if(!isset($proofTypes[$extension])||!in_array($mime,$proofTypes[$extension],true))throw new RuntimeException('Payment proof must be a PNG, JPG, WebP, or PDF.');
            $directory=dirname(__DIR__).'/uploads/payments';
            if(!is_dir($directory)&&!mkdir($directory,0750,true)&&!is_dir($directory))throw new RuntimeException('Payment proof storage is unavailable.');
            if(!is_writable($directory))throw new RuntimeException('Payment proof storage is not writable.');
            $filename=bin2hex(random_bytes(18)).'.'.($extension==='jpeg'?'jpg':$extension);
            $target=$directory.'/'.$filename;
            if(!move_uploaded_file($temp,$target))throw new RuntimeException('Could not save payment proof.');
            if(!chmod($target,0640)&&(((int)fileperms($target)&0777)!==0640)){unlink($target);throw new RuntimeException('Could not secure payment proof permissions.');}
            $savedProof=$filename;
        }
        $pdo=db();
        $pdo->beginTransaction();
        if($addressMode==='new'){
            $pdo->prepare("INSERT INTO user_billing_addresses(user_id,label,billing_name,email,phone,company_name,address_line_1,address_line_2,city,state_province,postal_code,country,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())")
                ->execute([$uid,$address['label']!==''?$address['label']:'Billing address',$address['billing_name'],$address['email'],$address['phone']?:null,$address['company_name']?:null,$address['address_line_1'],$address['address_line_2']?:null,$address['city'],$address['state_province'],$address['postal_code'],$address['country']]);
        }
        $snapshot=json_encode(array_intersect_key($address,array_flip(['label','billing_name','email','phone','company_name','address_line_1','address_line_2','city','state_province','postal_code','country'])),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
        $token=bin2hex(random_bytes(10));
        $pdo->prepare("INSERT INTO subscription_requests(user_id,plan,billing_cycle,amount,payment_method,billing_snapshot,waiting_token,status,proof_path,payment_reference,created_at,updated_at) VALUES(?,?,?,?,?,?,?,'pending',?,?,NOW(),NOW())")
            ->execute([$uid,$plan,$cycle,$amount,$paymentMethod,$snapshot,$token,$savedProof,$paymentReference!==''?$paymentReference:null]);
        $requestId=(int)$pdo->lastInsertId();
        $threadId=billing_support_thread($uid);
        $pdo->prepare('UPDATE support_threads SET subscription_request_id=?,updated_at=NOW() WHERE id=?')->execute([$requestId,$threadId]);
        $addressText=implode(', ',array_filter([$address['label']??'',$address['billing_name'],$address['email'],$address['phone']??'',$address['company_name']??'',$address['address_line_1'],$address['address_line_2']??'',$address['city'],$address['state_province'],$address['postal_code'],$address['country']]));
        $message="Billing request submitted\nRequest: {$token}\nPlan: ".($meta['name']??ucfirst($plan))." (".($cycle==='year'?'Yearly · 365 days':'Monthly · 30 days').")\nAmount: {$amount} USD\nPayment method: {$paymentMethod}\nTransaction/reference: ".($paymentReference!==''?$paymentReference:'Not provided')."\nPayment proof: ".($savedProof?'Attached to billing request':'Not uploaded')."\nBilling details: {$addressText}";
        $pdo->prepare("INSERT INTO support_messages(thread_id,sender_user_id,sender_role,body,attachment_path,attachment_paths,attachment_category,created_at) VALUES(?,?,'user',?,?,?, ?,NOW())")
            ->execute([$threadId,$uid,$message,$savedProof?'/support/proof/?request='.$requestId:null,$savedProof?json_encode(['/support/proof/?request='.$requestId],JSON_UNESCAPED_SLASHES):null,$savedProof?'Payment proof':null]);
        $pdo->prepare('UPDATE support_threads SET updated_at=NOW() WHERE id=?')->execute([$threadId]);
        $pdo->commit();
        flash('success','Billing request submitted. Track its status in Billing Support.');
        redirect('/support/?type=billing&thread='.$threadId);
    }catch(Throwable $e){
        if(db()->inTransaction())db()->rollBack();
        if($savedProof&&is_file(dirname(__DIR__).'/uploads/payments/'.$savedProof))unlink(dirname(__DIR__).'/uploads/payments/'.$savedProof);
        error_log('[PocketCat billing request] '.$e->getMessage());
        flash('error',$e instanceof RuntimeException?$e->getMessage():'Could not submit the billing request.');
        redirect('/billing/checkout/?plan='.rawurlencode($plan).'&cycle='.rawurlencode($cycle));
    }
}

$title='Checkout & Billing';
require __DIR__.'/../includes/header.php';
?>
<div class="page-head"><div><span class="eyebrow">Checkout & Billing</span><h1>Request <?=e((string)($meta['name']??ucfirst($plan)))?></h1><p>Choose payment instructions, add billing details, and submit a request for administrator verification.</p></div><div class="billing-current-plan"><span><?=e($cycle==='year'?'Yearly · 365 days':'Monthly · 30 days')?></span><strong><?=e($amount)?> USD</strong></div></div>
<?php foreach(flashes() as [$kind,$message]): ?><div class="flash <?=e($kind)?>"><?=e($message)?></div><?php endforeach; ?>
<div class="checkout-layout">
<form method="post" enctype="multipart/form-data" class="card form-card checkout-form">
  <?=csrf_field()?><input type="hidden" name="plan" value="<?=e($plan)?>"><input type="hidden" name="cycle" value="<?=e($cycle)?>">
  <section><h2>Payment method</h2><div class="checkout-methods"><?php foreach($methods as $key=>$label): ?><label class="checkout-method"><input type="radio" name="payment_method" value="<?=e($key)?>" <?=$key==='UPI'?'checked':''?>><span><?=e($label)?></span></label><?php endforeach; ?></div>
    <div class="checkout-payment-details" id="payment-instructions" data-upi="<?=e($methodDetails['UPI'])?>" data-bank="<?=e($methodDetails['Bank Transfer'])?>" data-card="<?=e($methodDetails['Card'])?>"><strong>Payment instructions</strong><p id="payment-instructions-text"><?=nl2br(e($methodDetails['UPI']))?></p><?php if($allowedQr): ?><img id="payment-qr" class="payment-qr" src="<?=e($qrUrl)?>" alt="Configured UPI payment QR code"><?php endif; ?></div>
    <label>Transaction / reference ID <span class="muted">(optional if proof is uploaded)</span><input name="payment_reference" maxlength="190" autocomplete="off"></label>
    <label>Payment proof <span class="muted">(PNG, JPG, WebP, or PDF · max 8 MB; optional if reference ID is provided)</span><input type="file" name="payment_proof" accept="image/png,image/jpeg,image/webp,application/pdf,.png,.jpg,.jpeg,.webp,.pdf"></label>
  </section>
  <section><h2>Billing details</h2>
    <?php if($addresses): ?><label class="billing-choice"><input type="radio" name="billing_choice" value="existing" checked> Use saved billing details</label><label>Saved address<select name="billing_address_id"><?php foreach($addresses as $address): ?><option value="<?=$address['id']?>"><?=e($address['label'])?> — <?=e($address['billing_name'])?>, <?=e($address['city'])?></option><?php endforeach; ?></select></label><?php else: ?><input type="hidden" name="billing_choice" value="new"><?php endif; ?>
    <label class="billing-choice"><input type="radio" name="billing_choice" value="new" <?=$addresses?'':'checked'?>> Add new billing details and save them</label>
    <div class="checkout-new-billing" id="new-billing-fields">
      <div class="billing-form-grid"><label>Label<input name="billing_label" value="Billing address" maxlength="80"></label><label>Name<input name="billing_name" value="<?=e($user['full_name'])?>" maxlength="180" required></label><label>Email<input type="email" name="billing_email" value="<?=e($user['email'])?>" maxlength="190" required></label><label>Phone<input name="billing_phone" maxlength="40"></label><label>Company <span class="muted">(optional)</span><input name="company_name" maxlength="180"></label><label>Address line 1<input name="address_line_1" maxlength="255" required></label><label>Address line 2 <span class="muted">(optional)</span><input name="address_line_2" maxlength="255"></label><label>City<input name="city" maxlength="120" required></label><label>State / Province<input name="state_province" maxlength="120" required></label><label>Postal code<input name="postal_code" maxlength="40" required></label><label>Country code<input name="country" maxlength="2" pattern="[A-Za-z]{2}" placeholder="IN" required></label></div>
    </div>
  </section>
  <p class="muted">No payment is processed by this form. The request remains Pending until an administrator verifies it.</p>
  <button class="btn full" type="submit">Submit Billing Request</button>
</form>
<aside class="card checkout-summary"><h2>Order summary</h2><p><strong><?=e((string)($meta['name']??ucfirst($plan)))?></strong><br><?=e($cycle==='year'?'Yearly billing (365 days)':'Monthly billing (30 days)')?></p><p class="checkout-total"><span>Total due</span><strong><?=e($amount)?> USD</strong></p><p class="muted">The plan starts when an administrator activates the verified request.</p></aside>
</div>
<script>
(function(){var instructions=document.getElementById('payment-instructions'),text=document.getElementById('payment-instructions-text'),radios=[...document.querySelectorAll('input[name="payment_method"]')],qr=document.getElementById('payment-qr'),choices=[...document.querySelectorAll('input[name="billing_choice"]')],newFields=document.getElementById('new-billing-fields');function updatePayment(){var selected=radios.find(function(x){return x.checked});if(!selected)return;var key=selected.value==='UPI'?'upi':selected.value==='Bank Transfer'?'bank':'card';text.textContent=instructions.dataset[key]||'';if(qr)qr.hidden=selected.value!=='UPI'}function updateBilling(){var selected=choices.find(function(x){return x.checked});if(newFields){newFields.hidden=!!selected&&selected.value!=='new';newFields.querySelectorAll('input,select,textarea').forEach(function(x){x.disabled=newFields.hidden})}}radios.forEach(function(x){x.addEventListener('change',updatePayment)});choices.forEach(function(x){x.addEventListener('change',updateBilling)});updatePayment();updateBilling()})();
</script>
<?php require __DIR__.'/../includes/footer.php'; ?>
