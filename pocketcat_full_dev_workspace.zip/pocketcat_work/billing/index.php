<?php
require __DIR__.'/../bootstrap.php';
require_login();
ensure_billing_workflow_schema();
billing_process_expirations();
plan_catalog_no_cache_headers();
$user=current_user();
$plan=(string)($user['plan']??'free');
$catalog=plan_catalog();
$q=db()->prepare("SELECT id,plan,billing_cycle,status,waiting_token,created_at FROM subscription_requests WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 5");
$q->execute([(int)$user['id']]);
$requests=$q->fetchAll();
$title='Plans & Billing';
require __DIR__.'/../includes/header.php';
?>
<div class="page-head billing-page-head"><div><span class="eyebrow">Plans & Billing</span><h1>Choose your plan</h1><p>Submit a billing request for administrator verification. Your plan changes only after activation.</p></div><div class="actions"><a class="btn secondary" href="/settings/">Billing Information</a><div class="billing-current-plan"><span>Current plan · <?=e((string)($user['subscription_status']??($plan==='free'?'free':'active')))?></span><strong><?=e(ucfirst($plan))?></strong><?php if(!empty($user['subscription_expires_at'])): ?><small>Expires <?=e((string)$user['subscription_expires_at'])?></small><?php endif; ?></div></div></div>
<?php foreach(flashes() as [$kind,$message]): ?><div class="flash <?=e($kind)?>"><?=e($message)?></div><?php endforeach; ?>
<?php if(policy_testing_mode()): ?><div class="testing-mode-banner"><strong>Testing Mode / All Features Unlocked</strong><span>Plan requests are still submitted for billing review; Testing Mode does not charge or activate subscriptions.</span></div><?php endif; ?>
<div class="plan-grid billing-plans"><?php foreach(['free','basic','premium'] as $planCardKey): if(empty($catalog['plan_meta'][$planCardKey]['enabled'])) continue; $planCardContext='billing'; $planCardCurrent=$plan; require __DIR__.'/../includes/plan-card.php'; endforeach; ?></div>
<?php if($requests): ?><section class="card billing-request-history"><h2>Recent billing requests</h2><div class="table-wrap"><table><thead><tr><th>Request</th><th>Plan</th><th>Cycle</th><th>Status</th><th>Submitted</th><th>Chat</th></tr></thead><tbody><?php foreach($requests as $request): ?><tr><td><code><?=e($request['waiting_token'])?></code></td><td><?=e(ucfirst($request['plan']))?></td><td><?=e($request['billing_cycle']==='year'?'Yearly':'Monthly')?></td><td><?=e(ucfirst($request['status']))?></td><td><?=e($request['created_at'])?></td><td><a class="btn small secondary" href="/support/?type=billing">Billing Support</a></td></tr><?php endforeach; ?></tbody></table></div></section><?php endif; ?>
<?php require __DIR__.'/../includes/footer.php'; ?>
