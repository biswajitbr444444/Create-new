<?php
require __DIR__.'/../bootstrap.php';
require_login();
ensure_billing_workflow_schema();
$uid=(int)current_user()['id'];
$channel=(string)getv('type','general')==='billing'?'billing':'general';
$tid=(int)getv('thread',0);

if($tid){
    $q=db()->prepare('SELECT * FROM support_threads WHERE id=? AND user_id=? AND channel=?');
    $q->execute([$tid,$uid,$channel]);
    $thread=$q->fetch();
}else{
    $q=db()->prepare('SELECT * FROM support_threads WHERE user_id=? AND channel=? ORDER BY updated_at DESC,id DESC LIMIT 1');
    $q->execute([$uid,$channel]);
    $thread=$q->fetch();
}
if(!$thread){
    $q=db()->prepare('INSERT INTO support_threads(user_id,channel,subscription_request_id,created_at,updated_at) VALUES(?,?,NULL,NOW(),NOW())');
    $q->execute([$uid,$channel]);
    $tid=(int)db()->lastInsertId();
    $q=db()->prepare('SELECT * FROM support_threads WHERE id=? AND user_id=?');
    $q->execute([$tid,$uid]);
    $thread=$q->fetch();
}
$tid=(int)$thread['id'];
$q=db()->prepare('SELECT * FROM support_messages WHERE thread_id=? ORDER BY id');
$q->execute([$tid]);
$messages=$q->fetchAll();
$request=null;
if($channel==='billing'){
    $q=db()->prepare('SELECT * FROM subscription_requests WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 1');
    $q->execute([$uid]);
    $request=$q->fetch()?:null;
}
$title=$channel==='billing'?'Billing Support':'General Support';
require __DIR__.'/../includes/header.php';
?>
<div class="page-head">
  <div><span class="eyebrow">Private support</span><h1><?=e($title)?></h1><p><?= $channel==='billing'?'Track plan upgrades, billing requests, and payment verification here.':'Get help with questions or troubleshooting that are not about a plan purchase.' ?></p></div>
  <div class="actions">
    <a class="btn <?=$channel==='general'?'':'secondary'?>" href="/support/?type=general">General Support</a>
    <a class="btn <?=$channel==='billing'?'':'secondary'?>" href="/support/?type=billing">Billing Support</a>
    <a class="btn secondary" href="/billing/">View plans</a>
  </div>
</div>
<div class="support-shell support-chat-live support-chat-user">
  <aside class="card">
    <h3><?=$channel==='billing'?'Billing requests':'General Support'?></h3>
    <?php if($request): ?>
      <p><strong>Latest request</strong><br><?=e(ucfirst((string)$request['plan']))?> · <?=e((string)$request['billing_cycle'])==='year'?'Yearly':'Monthly'?></p>
      <p><strong>Waiting token</strong><br><code><?=e($request['waiting_token'])?></code></p>
      <p>Status: <span id="support-status"><?=e($request['status'])?></span></p>
      <?php if($request['expiry_date']): ?><p>Plan expires: <?=e($request['expiry_date'])?></p><?php endif; ?>
      <div class="notice">Your billing request and any admin updates appear in this dedicated chat.</div>
    <?php elseif($channel==='billing'): ?>
      <p class="muted">Your billing questions and upgrade requests use a separate private thread.</p>
      <a class="btn small" href="/billing/">Start a plan request</a>
    <?php else: ?>
      <p class="muted">Private 1-on-1 support with the PocketCat admin team.</p>
      <div class="notice">You can ask questions or report problems here. A plan purchase is not required.</div>
    <?php endif; ?>
  </aside>
  <section class="card">
    <div class="support-messages" id="support-messages" data-thread="<?=$tid?>" data-channel="<?=e($channel)?>">
      <?php foreach($messages as $m): ?>
        <div class="support-message <?=$m['sender_role']==='user'?'from-user':'from-admin'?>" data-mid="<?=$m['id']?>">
          <small><?=e($m['sender_role']==='user'?'You':'Admin')?> · <?=e($m['created_at'])?></small><div><?=nl2br(e($m['body']))?></div>
          <?php $atts=json_decode((string)($m['attachment_paths']??''),true);if(!is_array($atts)||!$atts)$atts=!empty($m['attachment_path'])?[$m['attachment_path']]:[];foreach($atts as $att): ?>
            <p><a class="btn small secondary" target="_blank" rel="noopener" href="<?=e($att)?>">View attachment</a></p>
          <?php endforeach; ?>
        </div>
      <?php endforeach; ?>
    </div>
    <form id="support-form" class="support-composer" method="post" enctype="multipart/form-data">
      <?=csrf_field()?><input type="hidden" name="thread_id" value="<?=$tid?>">
      <textarea name="body" id="support-input" rows="3" placeholder="Message the PocketCat team…"></textarea>
      <div class="support-upload-picker"><strong>Upload files</strong><button type="button" class="btn small secondary" id="support-choose-files">Choose files</button><span class="muted">Bulk upload · resumable · retry/cancel</span><input type="file" id="support-file" name="files[]" multiple hidden accept="image/*,audio/*,video/*,.zip,.pdf,.txt,.csv,.json,.doc,.docx,.xls,.xlsx,.ppt,.pptx"></div>
      <div id="support-attachments" class="upload-list"></div>
      <div class="composer-row"><span class="muted">Replies appear here automatically.</span><button class="btn" type="submit">Send Message</button></div>
    </form>
  </section>
</div>
<script src="/assets/js/support-upload-v17.8.js?v=19.80-support-channels"></script>
<?php require __DIR__.'/../includes/footer.php'; ?>
