<?php
require __DIR__.'/../bootstrap.php';
require_login();
$user=current_user();
$file='';
$requestId=(int)getv('request',0);
if($requestId>0){
    $q=db()->prepare('SELECT proof_path,user_id FROM subscription_requests WHERE id=?');
    $q->execute([$requestId]);
    $request=$q->fetch();
    if(!$request||(($user['role']??'')!=='admin'&&(int)$request['user_id']!==(int)$user['id'])){http_response_code(404);exit('Not found.');}
    $file=(string)($request['proof_path']??'');
}else{
    $threadId=(int)getv('thread',0);
    $file=basename((string)getv('file',''));
    $q=db()->prepare('SELECT 1 FROM support_threads WHERE id=? AND user_id=?');
    $q->execute([$threadId,(int)$user['id']]);
    if(!$q->fetchColumn()&&($user['role']??'')!=='admin'){http_response_code(404);exit('Not found.');}
}
if(!preg_match('/^[a-f0-9]{36}\.(png|jpe?g|webp|pdf)$/i',$file)){http_response_code(404);exit('Not found.');}
$directory=realpath(__DIR__.'/../uploads/payments');
$path=$directory?realpath($directory.'/'.$file):false;
if(!$directory||!$path||dirname($path)!==$directory||!is_file($path)||!is_readable($path)){http_response_code(404);exit('Not found.');}
$mime=(new finfo(FILEINFO_MIME_TYPE))->file($path)?:'application/octet-stream';
if(!in_array($mime,['image/png','image/jpeg','image/webp','application/pdf'],true)){http_response_code(415);exit('Unsupported proof type.');}
header('Content-Type: '.$mime);
header('Content-Length: '.filesize($path));
$displayExtension=$mime==='application/pdf'?'pdf':($mime==='image/png'?'png':($mime==='image/webp'?'webp':'jpg'));
header('Content-Disposition: inline; filename="payment-proof.'.$displayExtension.'"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile($path);
exit;
