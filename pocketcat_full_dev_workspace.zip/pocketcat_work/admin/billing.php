<?php
require __DIR__.'/../bootstrap.php';
require_admin();
ensure_billing_workflow_schema();
billing_process_expirations();

if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    $action=(string)post('action','');
    try{
        if($action==='save_payment_details'){
            foreach(['billing_upi_details'=>3000,'billing_bank_details'=>3000,'billing_card_instructions'=>3000] as $key=>$limit){
                $value=trim((string)post($key,''));
                if(strlen($value)>$limit)throw new RuntimeException('Payment instructions are too long.');
                set_setting($key,$value);
            }
            $qr=trim((string)post('billing_upi_qr_url',''));
            if($qr!==''&&!((str_starts_with($qr,'/')&&!str_starts_with($qr,'//'))||(filter_var($qr,FILTER_VALIDATE_URL)&&strtolower((string)parse_url($qr,PHP_URL_SCHEME))==='https')))throw new RuntimeException('UPI QR URL must be a site-relative path or an HTTPS URL.');
            set_setting('billing_upi_qr_url',$qr);
            flash('success','Payment instructions saved.');
        }elseif(in_array($action,['activate','change_plan'],true)){
            $requestId=(int)post('request_id',0);
            $plan=$action==='activate'?null:(string)post('plan','');
            if($action==='activate'){
                $q=db()->prepare('SELECT plan FROM subscription_requests WHERE id=?');
                $q->execute([$requestId]);
                $plan=(string)$q->fetchColumn();
            }
            billing_activate_request($requestId,(string)$plan,(int)current_user()['id']);
            flash('success',$action==='activate'?'Billing request activated and customer notified.':'Customer plan changed and customer notified.');
        }elseif($action==='reject'){
            $requestId=(int)post('request_id',0);
            $note=trim((string)post('note',''));
            $pdo=db();$pdo->beginTransaction();
            $q=$pdo->prepare('SELECT user_id FROM subscription_requests WHERE id=? FOR UPDATE');
            $q->execute([$requestId]);
            $userId=(int)$q->fetchColumn();
            if(!$userId)throw new RuntimeException('Billing request was not found.');
            $pdo->prepare("UPDATE subscription_requests SET status='rejected',admin_note=?,updated_at=NOW() WHERE id=?")->execute([$note,$requestId]);
            if($note!=='')billing_chat_message(billing_support_thread($userId),(int)current_user()['id'],'Your billing request was reviewed but could not be approved. Admin note: '.$note);
            $pdo->commit();
            flash('success','Billing request rejected.');
        }else{
            throw new RuntimeException('Unknown billing action.');
        }
    }catch(Throwable $e){
        if(db()->inTransaction())db()->rollBack();
        error_log('[PocketCat admin billing] '.$e->getMessage());
        flash('error',$e instanceof RuntimeException?$e->getMessage():'Could not update billing.');
    }
    redirect('/admin/billing/');
}

$rows=db()->query("SELECT r.*,u.full_name,u.username,u.email,u.plan AS current_plan,u.subscription_status,u.subscription_expires_at,(SELECT st.id FROM support_threads st WHERE st.user_id=r.user_id AND st.channel='billing' ORDER BY st.updated_at DESC,st.id DESC LIMIT 1) AS billing_thread_id FROM subscription_requests r JOIN users u ON u.id=r.user_id ORDER BY r.created_at DESC,r.id DESC")->fetchAll();
foreach($rows as &$row)if(empty($row['billing_thread_id']))$row['billing_thread_id']=billing_support_thread((int)$row['user_id']);
unset($row);
$title='Billing Requests';
require __DIR__.'/../includes/header.php';
?>
<div class="page-head"><div><span class="eyebrow">Administration</span><h1>Billing Requests</h1><p>Review payment proof, manage customer plans, and configure payment instructions.</p></div></div>
<?php foreach(flashes() as [$kind,$message]): ?><div class="flash <?=e($kind)?>"><?=e($message)?></div><?php endforeach; ?>
<details class="card billing-payment-config"><summary><strong>Payment methods and instructions shown at checkout</strong></summary>
  <form method="post" class="form-card"><?=csrf_field()?><input type="hidden" name="action" value="save_payment_details">
    <label>UPI instructions<textarea name="billing_upi_details" rows="4"><?=e(setting('billing_upi_details',''))?></textarea></label>
    <label>UPI QR image URL <small>Site-relative path or HTTPS image URL.</small><input name="billing_upi_qr_url" value="<?=e(setting('billing_upi_qr_url',''))?>" type="text" inputmode="url" placeholder="https://… or /uploads/…"></label>
    <label>Bank transfer instructions<textarea name="billing_bank_details" rows="4"><?=e(setting('billing_bank_details',''))?></textarea></label>
    <label>Credit/debit card instructions<textarea name="billing_card_instructions" rows="4"><?=e(setting('billing_card_instructions',''))?></textarea></label>
    <button class="btn" type="submit">Save Payment Instructions</button>
  </form>
</details>
<div class="card table-wrap billing-requests-table"><table><thead><tr><th>Customer</th><th>Plan / Cycle</th><th>Amount</th><th>Method</th><th>Waiting Token</th><th>Status</th><th>Proof / Reference</th><th>Action</th></tr></thead><tbody>
<?php foreach($rows as $row):
    $billingDetails=json_decode((string)($row['billing_snapshot']??''),true);
    $billingDetails=is_array($billingDetails)?$billingDetails:[];
?>
<tr>
  <td><strong><?=e($row['username'])?></strong><br><?=e($row['full_name'])?><br><small><?=e($row['email'])?></small>
    <?php if($billingDetails): ?><details><summary>Billing details</summary><small><?=e(implode(', ',array_filter([$billingDetails['label']??'',$billingDetails['billing_name']??'',$billingDetails['email']??'',$billingDetails['phone']??'',$billingDetails['company_name']??'',$billingDetails['address_line_1']??'',$billingDetails['address_line_2']??'',$billingDetails['city']??'',$billingDetails['state_province']??'',$billingDetails['postal_code']??'',$billingDetails['country']??''])))?></small></details><?php endif; ?>
  </td>
  <td><?=e(ucfirst((string)$row['plan']))?><br><small><?=e($row['billing_cycle']==='year'?'Yearly':'Monthly')?></small><br><small>Current: <?=e(ucfirst((string)$row['current_plan']))?> · <?=e((string)$row['subscription_status'])?></small><?php if($row['subscription_expires_at']): ?><br><small>Expires <?=e($row['subscription_expires_at'])?></small><?php endif; ?></td>
  <td><?=e($row['amount'])?> USD</td><td><?=e($row['payment_method'])?></td><td><code><?=e($row['waiting_token'])?></code></td><td><?=e(ucfirst((string)$row['status']))?></td>
  <td><?php if($row['proof_path']): ?><a class="btn small secondary" href="/support/proof/?request=<?=$row['id']?>" target="_blank" rel="noopener">View proof</a><?php else: ?>—<?php endif; ?><?php if($row['payment_reference']): ?><br><small>Ref: <?=e($row['payment_reference'])?></small><?php endif; ?></td>
  <td class="billing-action-cell">
    <a class="btn small secondary" href="/admin/support/thread/?thread=<?=(int)$row['billing_thread_id']?>&amp;channel=billing">Chat</a>
    <form method="post"><?=csrf_field()?><input type="hidden" name="request_id" value="<?=$row['id']?>"><label class="sr-only" for="plan-<?=$row['id']?>">Set plan for <?=e($row['username'])?></label><select id="plan-<?=$row['id']?>" name="plan"><option value="free" <?=$row['current_plan']==='free'?'selected':''?>>Free / Basic</option><option value="basic" <?=$row['current_plan']==='basic'?'selected':''?>>Basic</option><option value="premium" <?=$row['current_plan']==='premium'?'selected':''?>>Premium / Pro</option></select><button class="btn small secondary" name="action" value="change_plan">Update plan</button><button class="btn small" name="action" value="activate" <?=in_array($row['status'],['active','approved'],true)?'disabled':''?>>Activate</button><label><span class="sr-only">Admin note</span><input name="note" maxlength="1000" placeholder="Admin note"></label><button class="btn small danger" name="action" value="reject">Reject</button></form>
  </td>
</tr>
<?php endforeach; ?>
<?php if(!$rows): ?><tr><td colspan="8">No billing requests have been submitted.</td></tr><?php endif; ?>
</tbody></table></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
