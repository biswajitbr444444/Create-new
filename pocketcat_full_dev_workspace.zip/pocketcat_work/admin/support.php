<?php
require __DIR__.'/../bootstrap.php';
require_admin();
ensure_billing_workflow_schema();
$channel=(string)getv('channel','general')==='billing'?'billing':'general';
$tid=(int)getv('thread',0);
$q=db()->prepare('SELECT st.*,u.full_name,u.username,u.email FROM support_threads st JOIN users u ON u.id=st.user_id WHERE st.channel=? ORDER BY st.updated_at DESC,st.id DESC');
$q->execute([$channel]);
$threads=$q->fetchAll();
$thread=null;
$messages=[];
if($tid){
    $q=db()->prepare('SELECT * FROM support_threads WHERE id=? AND channel=?');
    $q->execute([$tid,$channel]);
    $thread=$q->fetch()?:null;
    if($thread){
        $q=db()->prepare('SELECT * FROM support_messages WHERE thread_id=? ORDER BY id');
        $q->execute([$tid]);
        $messages=$q->fetchAll();
    }
}
$title=$channel==='billing'?'Billing Support':'General Support';
require __DIR__.'/../includes/header.php';
?>
<div class="page-head"><div><span class="eyebrow">Administration</span><h1><?=$title?> Chat</h1><p>Private 1-on-1 <?=strtolower($title)?> conversations. Messages refresh automatically.</p></div><div class="actions"><a class="btn <?=$channel==='general'?'':'secondary'?>" href="/admin/support/?channel=general">General Support</a><a class="btn <?=$channel==='billing'?'':'secondary'?>" href="/admin/support/?channel=billing">Billing Support</a></div></div>
<div class="support-shell support-chat-live support-chat-admin">
  <aside class="card"><h3><?= $channel==='billing'?'Billing Customers':'Customers' ?></h3><div id="thread-list">
    <?php foreach($threads as $t): ?>
      <a class="chat-session <?=$t['id']===$tid?'active':''?>" href="/admin/support/thread/?thread=<?=$t['id']?>&amp;channel=<?=e($channel)?>"><strong><?=e($t['full_name'])?></strong><small class="muted"> · <?=e($t['status'])?></small><br><span class="muted"><?=e($t['username'])?> · <?=e($t['email'])?></span></a>
    <?php endforeach; ?>
    <?php if(!$threads): ?><p class="muted">No <?=strtolower($title)?> conversations yet.</p><?php endif; ?>
  </div></aside>
  <section class="card">
    <?php if($thread): ?>
      <div class="support-messages" id="support-messages" data-thread="<?=$tid?>" data-channel="<?=e($channel)?>">
        <?php foreach($messages as $m): ?>
          <div class="support-message <?=$m['sender_role']==='admin'?'from-admin':'from-user'?>" data-mid="<?=$m['id']?>">
            <small><?=e($m['sender_role']==='admin'?'Admin':'Customer')?> · <?=e($m['created_at'])?></small><div><?=nl2br(e($m['body']))?></div>
            <?php $atts=json_decode((string)($m['attachment_paths']??''),true);if(!is_array($atts)||!$atts)$atts=!empty($m['attachment_path'])?[$m['attachment_path']]:[];foreach($atts as $att): ?>
              <p><a class="btn small secondary" target="_blank" rel="noopener" href="<?=e($att)?>">Open attachment</a></p>
            <?php endforeach; ?>
          </div>
        <?php endforeach; ?>
      </div>
      <form id="support-form" class="support-composer" method="post" enctype="multipart/form-data">
        <?=csrf_field()?><input type="hidden" name="thread_id" value="<?=$tid?>">
        <textarea name="body" id="support-input" rows="3" placeholder="Reply to <?=e($thread['full_name'])?>…"></textarea>
        <div class="support-upload-picker"><strong>Upload files</strong><button type="button" class="btn small secondary" id="support-choose-files">Choose files</button><span class="muted">Bulk upload · resumable · retry/cancel</span><input type="file" id="support-file" name="files[]" multiple hidden accept="image/*,audio/*,video/*,.zip,.pdf,.txt,.csv,.json,.doc,.docx,.xls,.xlsx,.ppt,.pptx"></div>
        <div id="support-attachments" class="upload-list"></div>
        <div class="composer-row"><span class="muted">Your replies are delivered to this customer.</span><button class="btn" type="submit">Send Reply</button></div>
      </form>
    <?php else: ?><div class="support-messages"><p class="muted">Choose a customer conversation to view messages and reply.</p></div><?php endif; ?>
  </section>
</div>
<?php if($thread): ?><script src="/assets/js/support-upload-v17.8.js?v=19.80-support-channels"></script><?php endif; ?>
<?php require __DIR__.'/../includes/footer.php'; ?>
