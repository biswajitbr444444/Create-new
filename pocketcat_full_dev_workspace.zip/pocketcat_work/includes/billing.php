<?php
declare(strict_types=1);

function billing_sandbox_enabled():bool{
    return strtolower((string)getenv('APP_ENV'))==='local'&&strtolower((string)getenv('BILLING_SANDBOX'))==='true';
}

function ensure_billing_workflow_schema():void{
    static $ready=false;
    if($ready)return;
    $pdo=db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_billing_addresses(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,label VARCHAR(80) NOT NULL DEFAULT 'Billing address',billing_name VARCHAR(180) NOT NULL,email VARCHAR(190) NOT NULL,phone VARCHAR(40) NULL,company_name VARCHAR(180) NULL,address_line_1 VARCHAR(255) NOT NULL,address_line_2 VARCHAR(255) NULL,city VARCHAR(120) NOT NULL,state_province VARCHAR(120) NOT NULL,postal_code VARCHAR(40) NOT NULL,country VARCHAR(2) NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,INDEX idx_user_billing_addresses(user_id,updated_at),CONSTRAINT fk_billing_address_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $addColumn=static function(string $table,string $column,string $sql) use($pdo):void{
        $q=$pdo->prepare('SHOW COLUMNS FROM `'.$table.'` LIKE ?');
        $q->execute([$column]);
        if(!$q->fetch())$pdo->exec($sql);
    };
    $addColumn('subscription_requests','billing_cycle',"ALTER TABLE subscription_requests ADD COLUMN billing_cycle ENUM('month','year') NOT NULL DEFAULT 'month' AFTER plan");
    $addColumn('subscription_requests','billing_snapshot',"ALTER TABLE subscription_requests ADD COLUMN billing_snapshot LONGTEXT NULL AFTER payment_method");
    $addColumn('subscription_requests','payment_reference',"ALTER TABLE subscription_requests ADD COLUMN payment_reference VARCHAR(190) NULL AFTER proof_path");
    $addColumn('subscription_requests','start_date',"ALTER TABLE subscription_requests ADD COLUMN start_date DATETIME NULL AFTER admin_note");
    $addColumn('subscription_requests','expiry_date',"ALTER TABLE subscription_requests ADD COLUMN expiry_date DATETIME NULL AFTER start_date");
    $pdo->exec("ALTER TABLE subscription_requests MODIFY plan VARCHAR(30) NOT NULL, MODIFY payment_method VARCHAR(40) NOT NULL, MODIFY status ENUM('pending','active','rejected','expired','waiting','proof_uploaded','approved') NOT NULL DEFAULT 'pending'");
    $addColumn('support_threads','channel',"ALTER TABLE support_threads ADD COLUMN channel VARCHAR(16) NOT NULL DEFAULT 'general' AFTER user_id");
    $pdo->exec("UPDATE support_threads SET channel=IF(subscription_request_id IS NULL,'general','billing') WHERE channel='general' AND subscription_request_id IS NOT NULL");
    $addColumn('support_messages','attachment_paths',"ALTER TABLE support_messages ADD COLUMN attachment_paths LONGTEXT NULL AFTER attachment_path");
    $addColumn('users','subscription_started_at',"ALTER TABLE users ADD COLUMN subscription_started_at DATETIME NULL AFTER plan");
    $addColumn('users','subscription_expires_at',"ALTER TABLE users ADD COLUMN subscription_expires_at DATETIME NULL AFTER subscription_started_at");
    $addColumn('users','subscription_status',"ALTER TABLE users ADD COLUMN subscription_status ENUM('free','active','expired') NOT NULL DEFAULT 'free' AFTER subscription_expires_at");
    $indexes=$pdo->query("SHOW INDEX FROM users WHERE Key_name='idx_users_subscription_expiry'")->fetchAll();
    if(!$indexes)$pdo->exec('ALTER TABLE users ADD INDEX idx_users_subscription_expiry(subscription_status,subscription_expires_at)');

    $ready=true;
}

function billing_process_expirations():int{
    $stmt=db()->prepare("UPDATE users SET plan='free',subscription_status='expired',updated_at=NOW() WHERE subscription_status='active' AND subscription_expires_at IS NOT NULL AND subscription_expires_at<=NOW()");
    $stmt->execute();
    $count=$stmt->rowCount();
    db()->exec("UPDATE subscription_requests SET status='expired',updated_at=NOW() WHERE status='active' AND expiry_date IS NOT NULL AND expiry_date<=NOW()");
    return $count;
}

function billing_plan_amount(string $plan,string $cycle):string{
    if(!in_array($plan,['basic','premium'],true)||!in_array($cycle,['month','year'],true))throw new InvalidArgumentException('Choose a valid plan and billing cycle.');
    $meta=plan_catalog()['plan_meta'][$plan]??[];
    if(empty($meta['enabled'])||!is_numeric($meta['price'])||(float)$meta['price']<0)throw new InvalidArgumentException('The selected plan is unavailable.');
    $base=(float)$meta['price'];
    $configured=(string)($meta['period']??'month');
    $amount=$configured==='year'?($cycle==='year'?$base:$base/12):($cycle==='year'?$base*12:$base);
    return number_format($amount,2,'.','');
}

function billing_support_thread(int $userId):int{
    $pdo=db();
    $q=$pdo->prepare("SELECT id FROM support_threads WHERE user_id=? AND channel='billing' ORDER BY updated_at DESC,id DESC LIMIT 1");
    $q->execute([$userId]);
    $id=(int)$q->fetchColumn();
    if($id>0)return $id;
    $pdo->prepare("INSERT INTO support_threads(user_id,channel,subscription_request_id,created_at,updated_at) VALUES(?,'billing',NULL,NOW(),NOW())")->execute([$userId]);
    return (int)$pdo->lastInsertId();
}

function billing_chat_message(int $threadId,int $senderId,string $body):void{
    db()->prepare("INSERT INTO support_messages(thread_id,sender_user_id,sender_role,body,created_at) VALUES(?,?,'admin',?,NOW())")->execute([$threadId,$senderId,$body]);
    db()->prepare('UPDATE support_threads SET updated_at=NOW() WHERE id=?')->execute([$threadId]);
}

function billing_activate_request(int $requestId,string $plan,int $adminId):void{
    if(!in_array($plan,['free','basic','premium'],true))throw new InvalidArgumentException('Select a valid plan.');
    $pdo=db();$pdo->beginTransaction();
    try{
        $q=$pdo->prepare('SELECT * FROM subscription_requests WHERE id=? FOR UPDATE');$q->execute([$requestId]);$request=$q->fetch();
        if(!$request)throw new RuntimeException('Billing request was not found.');
        $userId=(int)$request['user_id'];
        $subscriptionStatus=$plan==='free'?'free':'active';
        $days=(string)$request['billing_cycle']==='year'?365:30;
        $pdo->prepare("UPDATE users SET plan=?,subscription_started_at=IF(?='free',NULL,NOW()),subscription_expires_at=IF(?='free',NULL,DATE_ADD(NOW(),INTERVAL ? DAY)),subscription_status=?,updated_at=NOW() WHERE id=?")->execute([$plan,$plan,$plan,$days,$subscriptionStatus,$userId]);
        $pdo->prepare("UPDATE subscription_requests SET plan=?,status='active',start_date=IF(?='free',NULL,NOW()),expiry_date=IF(?='free',NULL,DATE_ADD(NOW(),INTERVAL ? DAY)),updated_at=NOW() WHERE id=?")->execute([$plan,$plan,$plan,$days,$requestId]);
        $q=$pdo->prepare('SELECT subscription_expires_at FROM users WHERE id=?');$q->execute([$userId]);$expiry=$q->fetchColumn();
        $threadId=billing_support_thread($userId);
        $name=(string)(plan_catalog()['plan_meta'][$plan]['name']??ucfirst($plan));
        $body=$plan==='free'?'Your account is now on the Free plan.':"Your {$name} plan has been successfully activated through ".((string)$request['billing_cycle']==='year'?'yearly':'monthly')." billing. It is active until {$expiry}.";
        billing_chat_message($threadId,$adminId,$body);
        $pdo->commit();
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}

function ensure_billing_sandbox_schema():void{
    static $ready=false;
    if($ready)return;
    db()->exec("CREATE TABLE IF NOT EXISTS billing_sandbox_transactions(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,plan ENUM('basic','premium') NOT NULL,amount DECIMAL(10,2) NOT NULL,currency CHAR(3) NOT NULL DEFAULT 'USD',provider_reference VARCHAR(100) NOT NULL UNIQUE,status ENUM('completed','failed') NOT NULL,created_at DATETIME NOT NULL,INDEX(user_id,created_at),CONSTRAINT fk_billing_sandbox_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $ready=true;
}

function billing_sandbox_checkout(int $userId,string $plan,?callable $processor=null):array{
    if(!billing_sandbox_enabled())throw new RuntimeException('Local billing sandbox is disabled.');
    if($processor!==null&&PHP_SAPI!=='cli')throw new RuntimeException('Mock billing processors are available only to CLI tests.');
    if($userId<1||!in_array($plan,['basic','premium'],true))throw new InvalidArgumentException('Choose an available paid plan.');
    $catalog=plan_catalog();$meta=$catalog['plan_meta'][$plan]??null;
    if(!is_array($meta)||empty($meta['enabled'])||!is_numeric($meta['price'])||(float)$meta['price']<=0)throw new InvalidArgumentException('The selected plan is not available for sandbox checkout.');
    $amount=number_format((float)$meta['price'],2,'.','');
    $processor??=static fn(int $uid,string $planKey,string $price):array=>['status'=>'authorized','reference'=>'sandbox_'.bin2hex(random_bytes(16))];
    $payment=$processor($userId,$plan,$amount);
    if(!is_array($payment)||($payment['status']??'')!=='authorized'||!is_string($payment['reference']??null)||!preg_match('/^sandbox_[a-f0-9]{32}$/D',$payment['reference']))throw new RuntimeException('Local payment sandbox did not authorize the checkout.');
    ensure_billing_sandbox_schema();
    $pdo=db();$ownsTransaction=!$pdo->inTransaction();
    if($ownsTransaction)$pdo->beginTransaction();
    try{
        $user=$pdo->prepare("SELECT id FROM users WHERE id=? AND status='active' FOR UPDATE");$user->execute([$userId]);
        if(!$user->fetchColumn())throw new RuntimeException('An active account is required to complete checkout.');
        $pdo->prepare("INSERT INTO billing_sandbox_transactions(user_id,plan,amount,currency,provider_reference,status,created_at) VALUES(?,?,?,'USD',?,'completed',NOW())")->execute([$userId,$plan,$amount,$payment['reference']]);
        $pdo->prepare('UPDATE users SET plan=?,updated_at=NOW() WHERE id=?')->execute([$plan,$userId]);
        if($ownsTransaction)$pdo->commit();
    }catch(Throwable $e){
        if($ownsTransaction&&$pdo->inTransaction())$pdo->rollBack();
        throw $e;
    }
    return ['plan'=>$plan,'amount'=>$amount,'currency'=>'USD','reference'=>$payment['reference']];
}
