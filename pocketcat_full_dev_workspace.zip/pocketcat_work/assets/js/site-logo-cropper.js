(function () {
    'use strict';

    function init() {
        const form = document.getElementById('website-name');
        const input = document.getElementById('site-logo-file');
        const preview = document.getElementById('site-logo-preview');
        const remove = document.getElementById('remove-site-logo');
        const modal = document.getElementById('logo-crop-modal');
        const canvas = document.getElementById('logo-crop-canvas');
        const zoomControl = document.getElementById('logo-crop-zoom');
        const applyButton = document.getElementById('logo-crop-apply');
        if (!form || !input || !preview || !modal || !canvas || !zoomControl || !applyButton) return;

        const context = canvas.getContext('2d');
        const initialPreview = preview.innerHTML;
        let source = null;
        let sourceUrl = '';
        let baseScale = 1;
        let zoom = 1;
        let imageX = 0;
        let imageY = 0;
        let scaledWidth = 0;
        let scaledHeight = 0;
        let dragging = false;
        let lastPointer = null;
        let previewUrl = '';

        function clampImage() {
            imageX = Math.min(0, Math.max(canvas.width - scaledWidth, imageX));
            imageY = Math.min(0, Math.max(canvas.height - scaledHeight, imageY));
        }

        function drawVisibleImage(target) {
            const scale = baseScale * zoom;
            const left = Math.max(0, imageX);
            const top = Math.max(0, imageY);
            const right = Math.min(canvas.width, imageX + scaledWidth);
            const bottom = Math.min(canvas.height, imageY + scaledHeight);
            if (right <= left || bottom <= top) return;
            const sourceX = (left - imageX) / scale;
            const sourceY = (top - imageY) / scale;
            const sourceWidth = (right - left) / scale;
            const sourceHeight = (bottom - top) / scale;
            target.drawImage(source, sourceX, sourceY, sourceWidth, sourceHeight, left, top, right - left, bottom - top);
        }

        function draw() {
            if (!source || !context) return;
            const oldCenterX = imageX + scaledWidth / 2;
            const oldCenterY = imageY + scaledHeight / 2;
            zoom = Number(zoomControl.value) || 1;
            scaledWidth = source.naturalWidth * baseScale * zoom;
            scaledHeight = source.naturalHeight * baseScale * zoom;
            imageX = oldCenterX - scaledWidth / 2;
            imageY = oldCenterY - scaledHeight / 2;
            clampImage();
            context.clearRect(0, 0, canvas.width, canvas.height);
            context.fillStyle = '#f6f8fc';
            context.fillRect(0, 0, canvas.width, canvas.height);
            drawVisibleImage(context);
        }

        function showPreview(blob) {
            if (previewUrl) URL.revokeObjectURL(previewUrl);
            previewUrl = URL.createObjectURL(blob);
            preview.innerHTML = '';
            const image = document.createElement('img');
            image.alt = 'Cropped website logo preview';
            image.src = previewUrl;
            preview.appendChild(image);
        }

        function closeCropper() {
            modal.hidden = true;
            if (sourceUrl) URL.revokeObjectURL(sourceUrl);
            sourceUrl = '';
            source = null;
            input.value = '';
        }

        input.addEventListener('change', function () {
            const file = input.files && input.files[0];
            input.value = '';
            if (!file) return;
            if (file.size > 5 * 1024 * 1024) {
                alert('The logo must be 5 MB or smaller.');
                return;
            }
            if (!/^image\/(png|jpeg|svg\+xml|webp)$/.test(file.type) && !/\.(png|jpe?g|svg|webp)$/i.test(file.name)) {
                alert('Choose a valid PNG, JPG, SVG, or WebP image.');
                return;
            }
            if (sourceUrl) URL.revokeObjectURL(sourceUrl);
            sourceUrl = URL.createObjectURL(file);
            const image = new Image();
            image.onload = function () {
                if (image.naturalWidth > 12000 || image.naturalHeight > 12000 || image.naturalWidth * image.naturalHeight > 40000000) {
                    URL.revokeObjectURL(sourceUrl);
                    sourceUrl = '';
                    alert('Logo dimensions must be 12,000 pixels or smaller on each side and no more than 40 megapixels.');
                    return;
                }
                if (!image.naturalWidth || !image.naturalHeight) {
                    URL.revokeObjectURL(sourceUrl);
                    sourceUrl = '';
                    alert('The selected image has invalid dimensions.');
                    return;
                }
                source = image;
                baseScale = Math.max(canvas.width / image.naturalWidth, canvas.height / image.naturalHeight);
                zoomControl.value = '1';
                zoom = 1;
                scaledWidth = image.naturalWidth * baseScale;
                scaledHeight = image.naturalHeight * baseScale;
                imageX = (canvas.width - scaledWidth) / 2;
                imageY = (canvas.height - scaledHeight) / 2;
                draw();
                modal.hidden = false;
                document.getElementById('logo-crop-cancel')?.focus();
                if (remove) remove.checked = false;
            };
            image.onerror = function () {
                URL.revokeObjectURL(sourceUrl);
                sourceUrl = '';
                alert('The selected image could not be opened.');
            };
            image.src = sourceUrl;
        });

        zoomControl.addEventListener('input', draw);
        document.getElementById('logo-crop-center')?.addEventListener('click', function () {
            imageX = (canvas.width - scaledWidth) / 2;
            imageY = (canvas.height - scaledHeight) / 2;
            draw();
        });
        document.getElementById('logo-crop-cancel')?.addEventListener('click', closeCropper);
        modal.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') closeCropper();
        });
        canvas.addEventListener('pointerdown', function (event) {
            dragging = true;
            lastPointer = {x: event.clientX, y: event.clientY};
            canvas.setPointerCapture(event.pointerId);
        });
        canvas.addEventListener('pointermove', function (event) {
            if (!dragging || !lastPointer) return;
            const rect = canvas.getBoundingClientRect();
            imageX += (event.clientX - lastPointer.x) * canvas.width / rect.width;
            imageY += (event.clientY - lastPointer.y) * canvas.height / rect.height;
            lastPointer = {x: event.clientX, y: event.clientY};
            draw();
        });
        ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(function (type) {
            canvas.addEventListener(type, function () { dragging = false; lastPointer = null; });
        });
        applyButton.addEventListener('click', function () {
            if (!source) return;
            const output = document.createElement('canvas');
            output.width = 320;
            output.height = 80;
            const outputContext = output.getContext('2d');
            if (!outputContext) {
                alert('Logo cropping is not available in this browser.');
                return;
            }
            drawVisibleImage(outputContext);
            output.toBlob(function (blob) {
                if (!blob) {
                    alert('Could not create the cropped logo image.');
                    return;
                }
                const croppedFile = new File([blob], 'website-logo.png', {type: 'image/png', lastModified: Date.now()});
                const transfer = new DataTransfer();
                transfer.items.add(croppedFile);
                input.files = transfer.files;
                showPreview(blob);
                modal.hidden = true;
                if (sourceUrl) URL.revokeObjectURL(sourceUrl);
                sourceUrl = '';
                source = null;
            }, 'image/png');
        });

        if (remove) {
            remove.addEventListener('change', function () {
                if (remove.checked) {
                    input.value = '';
                    preview.innerHTML = '<span class="brand-mark" aria-label="Default PocketCat icon">P</span>';
                } else {
                    preview.innerHTML = initialPreview;
                }
            });
        }
        form.addEventListener('submit', function (event) {
            const button = form.querySelector('button[type="submit"]');
            if (button) {
                button.disabled = true;
                button.textContent = 'Saving…';
            }
            if (modal.hidden === false) {
                event.preventDefault();
                if (button) {
                    button.disabled = false;
                    button.textContent = 'Save Site Settings';
                }
                alert('Apply the logo crop or cancel before saving.');
            }
        });
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once: true});
    else init();
}());
