<?php
$GLOBALS['test_settings'] = [];
function setting(string $key, ?string $default = null): ?string { return $GLOBALS['test_settings'][$key] ?? $default; }
function set_setting(string $key, string $value): void { $GLOBALS['test_settings'][$key] = $value; }
require __DIR__.'/../includes/policy.php';
require __DIR__.'/../includes/plan-catalog.php';
require __DIR__.'/../includes/billing.php';
$catalogConfig = policy_defaults();
$catalogConfig['plan_meta']['basic']['price'] = '10';
$catalogConfig['plan_meta']['basic']['period'] = 'month';
$catalogConfig['plan_meta']['premium']['price'] = '120';
$catalogConfig['plan_meta']['premium']['period'] = 'year';
set_setting('policy_engine', json_encode($catalogConfig));
$GLOBALS['_policy_data_cache'] = null;

$billingPage = file_get_contents(__DIR__.'/../billing/index.php');
$planCard = file_get_contents(__DIR__.'/../includes/plan-card.php');
$checkout = file_get_contents(__DIR__.'/../billing/checkout.php');
$billingAdmin = file_get_contents(__DIR__.'/../admin/billing.php');
$billingHelpers = file_get_contents(__DIR__.'/../includes/billing.php');
$userSupport = file_get_contents(__DIR__.'/../support/index.php');
$adminSupport = file_get_contents(__DIR__.'/../admin/support.php');
$supportApi = file_get_contents(__DIR__.'/../api/support-chat.php');
$schema = file_get_contents(__DIR__.'/../database/schema.sql');
$proofAccess = file_get_contents(__DIR__.'/../uploads/payments/.htaccess');
$checks = [
    'paid plan selections route directly to monthly or yearly checkout' => strpos($planCard, '/billing/checkout/?plan=') !== false && strpos($planCard, '&amp;cycle=month') !== false && strpos($planCard, '&amp;cycle=year') !== false,
    'monthly and yearly amounts honor each plan catalog billing period' => billing_plan_amount('basic','month') === '10.00' && billing_plan_amount('basic','year') === '120.00' && billing_plan_amount('premium','month') === '10.00' && billing_plan_amount('premium','year') === '120.00',
    'checkout offers all payment types and accepts proof or a transaction reference' => strpos($checkout, "'UPI'=>'UPI / QR'") !== false && strpos($checkout, "'Bank Transfer'=>'Bank Transfer'") !== false && strpos($checkout, "'Card'=>'Credit / Debit Card'") !== false && strpos($checkout, 'payment_proof') !== false && strpos($checkout, 'payment_reference') !== false,
    'checkout saves user-owned billing details and creates a pending request' => strpos($checkout, 'WHERE id=? AND user_id=?') !== false && strpos($checkout, 'INSERT INTO user_billing_addresses') !== false && strpos($checkout, "'pending'") !== false,
    'checkout posts the submitted details and proof into Billing Support' => strpos($checkout, 'INSERT INTO support_messages') !== false && strpos($checkout, 'Billing request submitted') !== false && strpos($checkout, '/support/?type=billing&thread=') !== false,
    'uploaded payment proofs cannot be fetched directly outside the authenticated endpoint' => strpos($proofAccess, 'Require all denied') !== false && strpos(file_get_contents(__DIR__.'/../support/proof.php'), 'require_login()') !== false,
    'admin can open billing chat, activate requests, change plans, and reject requests' => strpos($billingAdmin, 'billing_thread_id') !== false && strpos($billingAdmin, 'value="activate"') !== false && strpos($billingAdmin, 'value="change_plan"') !== false && strpos($billingAdmin, 'value="reject"') !== false,
    'activation records 30-day or 365-day terms and posts a confirmation message' => strpos($billingHelpers, "==='year'?365:30") !== false && strpos($billingHelpers, "DATE_ADD(NOW(),INTERVAL ? DAY)") !== false && strpos($billingHelpers, 'successfully activated') !== false,
    'expired subscriptions revert to free and requests update to expired' => strpos($billingHelpers, "SET plan='free',subscription_status='expired'") !== false && strpos($billingHelpers, "SET status='expired'") !== false,
    'user and admin support pages separate General and Billing channels' => strpos($userSupport, "getv('type','general')") !== false && strpos($userSupport, 'type=billing') !== false && strpos($adminSupport, "getv('channel','general')") !== false && strpos($adminSupport, 'channel=billing') !== false,
    'support message API scopes both reads and sends to the selected channel' => strpos($supportApi, "in_array(\$channel,['general','billing'],true)") !== false && strpos($supportApi, 'support_access_thread($tid,$u,$channel)') !== false,
    'fresh database schema includes subscription dates, billing addresses, and chat channels' => strpos($schema, 'subscription_expires_at DATETIME NULL') !== false && strpos($schema, 'CREATE TABLE IF NOT EXISTS user_billing_addresses') !== false && strpos($schema, 'channel VARCHAR(16)') !== false,
];
$failed = false;
foreach ($checks as $label => $ok) {
    echo ($ok ? 'PASS: ' : 'FAIL: ').$label."\n";
    if (!$ok) $failed = true;
}
if ($failed) exit(1);
echo "All billing and support workflow checks passed.\n";
